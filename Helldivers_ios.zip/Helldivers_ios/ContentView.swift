//
//  ContentView.swift
//  Helldivers_ios
//
//  Created by csuftitan on 10/15/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        MainTabView()
    }
}

#Preview {
    ContentView()
}

// Unused for now
