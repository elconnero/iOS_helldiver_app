//
//  LoadoutsView.swift
//  Helldivers_ios
//
//  Created by Alvaro Contreras on 11/19/25.

//import SwiftUI
//
//struct Loadout: Identifiable {
//    let id = UUID()
//    let name: String
//    let playerCount: Int
//    let type: String
//}
//
//struct LoadoutsView: View {
//    @State private var loadouts: [Loadout] = [
//        Loadout(name: "Loadout 6", playerCount: 4, type: "Crowd Control"),
//        Loadout(name: "Loadout 5", playerCount: 4, type: "Crowd Control"),
//        Loadout(name: "Loadout 4", playerCount: 4, type: "Crowd Control"),
//        Loadout(name: "Loadout 3", playerCount: 4, type: "Crowd Control"),
//        Loadout(name: "Loadout 2", playerCount: 4, type: "Crowd Control"),
//        Loadout(name: "Loadout 1", playerCount: 4, type: "Crowd Control")
//    ]
//
//    var body: some View {
//        ZStack(alignment: .top) {
//            Color.black
//                .ignoresSafeArea()
//
//            ScrollView {
//                VStack(alignment: .leading, spacing: 16) {
//
//                    Text("Loadouts")
//                        .font(.custom("ChakraPetch-Bold", size: 34))
//                        .foregroundColor(.white)
//                        .frame(maxWidth: .infinity, alignment: .center)
//                        .padding(.top, 24)
//                        .padding(.bottom, 4)
//
//                    ForEach(loadouts) { loadout in
//                        LoadoutRow(loadout: loadout) {
//                            if let index = loadouts.firstIndex(where: { $0.id == loadout.id }) {
//                                loadouts.remove(at: index)
//                            }
//                        }
//                    }
//
//                    Spacer(minLength: 24)
//                }
//                .padding(.horizontal, 16)
//                .padding(.bottom, 40)
//            }
//            .background(Color.clear)
//        }
//    }
//}
//
//struct LoadoutRow: View {
//    let loadout: Loadout
//    let onDelete: () -> Void
//
//    var body: some View {
//        ZStack {
//            RoundedRectangle(cornerRadius: 18)
//                .fill(Color.white.opacity(0.08))
//
//            VStack(alignment: .leading, spacing: 12) {
//                HStack {
//                    Text(loadout.name)
//                        .foregroundColor(.white)
//                        .font(.system(size: 18, weight: .semibold))
//
//                    Spacer()
//
//                    Button(action: onDelete) {
//                        Image(systemName: "xmark")
//                            .font(.system(size: 14, weight: .bold))
//                            .foregroundColor(.white.opacity(0.7))
//                    }
//                }
//
//                Text("\(loadout.playerCount) Players | Type: \(loadout.type)")
//                    .foregroundColor(.white.opacity(0.7))
//                    .font(.system(size: 14))
//
//                HStack {
//                    Button {
//                        // Need to hook this up to view loadout screen
//                    } label: {
//                        Text("View")
//                            .font(.system(size: 16, weight: .semibold))
//                            .foregroundColor(.black)
//                            .padding(.horizontal, 28)
//                            .padding(.vertical, 10)
//                            .background(Color.helldiverYellow)
//                            .clipShape(Capsule())
//                    }
//
//                    Spacer()
//
//                    // Placeholder squares where the icons will go later
//                    HStack(spacing: 8) {
//                        ForEach(0..<5) { _ in
//                            RoundedRectangle(cornerRadius: 6)
//                                .fill(Color.white.opacity(0.16))
//                                .frame(width: 28, height: 28)
//                        }
//                    }
//                }
//            }
//            .padding(16)
//        }
//        .frame(maxWidth: .infinity)
//    }
//}



//
//import SwiftUI
//
//struct Loadout: Identifiable, Hashable {
//    let id = UUID()
//    let name: String
//    let playerCount: Int
//    let type: String
//}
//
//struct LoadoutsView: View {
//    @State private var loadouts: [Loadout] = [
//        Loadout(name: "Loadout 6", playerCount: 4, type: "Crowd Control"),
//        Loadout(name: "Loadout 5", playerCount: 4, type: "Crowd Control"),
//        Loadout(name: "Loadout 4", playerCount: 4, type: "Crowd Control"),
//        Loadout(name: "Loadout 3", playerCount: 4, type: "Crowd Control"),
//        Loadout(name: "Loadout 2", playerCount: 4, type: "Crowd Control"),
//        Loadout(name: "Loadout 1", playerCount: 4, type: "Crowd Control")
//    ]
//
//    var body: some View {
//        ZStack {
//            Color.black.ignoresSafeArea()
//
//            ScrollView {
//                VStack(alignment: .leading, spacing: 16) {
//
//                    // Title
//                    Text("Loadouts")
//                        .font(.custom("ChakraPetch-Bold", size: 32))
//                        .foregroundColor(.white)
//                        .frame(maxWidth: .infinity, alignment: .center)
//                        .padding(.top, 24)
//
//                    // Cards
//                    VStack(spacing: 16) {
//                        ForEach(loadouts) { loadout in
//                            LoadoutRow(
//                                loadout: loadout,
//                                onDelete: {
//                                    if let idx = loadouts.firstIndex(of: loadout) {
//                                        loadouts.remove(at: idx)
//                                    }
//                                }
//                            )
//                        }
//                    }
//                }
//                .padding(.horizontal, 16)
//                .padding(.bottom, 32)
//            }
//        }
//        .toolbar(.hidden, for: .navigationBar)
//    }
//}
//
//struct LoadoutRow: View {
//    let loadout: Loadout
//    let onDelete: () -> Void
//
//    var body: some View {
//        ZStack {
//            RoundedRectangle(cornerRadius: 16)
//                .fill(Color.white.opacity(0.06))
//
//            VStack(alignment: .leading, spacing: 12) {
//                HStack {
//                    Text(loadout.name)
//                        .foregroundColor(.white)
//                        .font(.system(size: 18, weight: .semibold))
//
//                    Spacer()
//
//                    Button(action: onDelete) {
//                        Image(systemName: "xmark")
//                            .foregroundColor(.white.opacity(0.7))
//                            .padding(6)
//                    }
//                }
//
//                Text("\(loadout.playerCount) Players | Type: \(loadout.type)")
//                    .foregroundColor(.white.opacity(0.7))
//                    .font(.system(size: 14))
//
//                HStack(spacing: 16) {
//                    // Navigation to detail screen
//                    NavigationLink {
//                        LoadoutDetailView(loadout: loadout)
//                    } label: {
//                        Text("View")
//                            .font(.system(size: 16, weight: .semibold))
//                            .foregroundColor(.black)
//                            .padding(.horizontal, 28)
//                            .padding(.vertical, 10)
//                            .background(Color.helldiverYellow)
//                            .cornerRadius(20)
//                    }
//                    .buttonStyle(.plain)
//
//                    Spacer()
//
//                    // Placeholder icon row
//                    HStack(spacing: 8) {
//                        ForEach(0..<5) { _ in
//                            RoundedRectangle(cornerRadius: 6)
//                                .fill(Color.white.opacity(0.12))
//                                .frame(width: 36, height: 36)
//                        }
//                    }
//                }
//                .padding(.top, 4)
//            }
//            .padding(16)
//        }
//        .frame(maxWidth: .infinity)
//    }
//}


import SwiftUI

struct LoadoutsView: View {
    @State private var loadouts: [SquadLoadout] = MockLoadouts.sample

    var body: some View {
        NavigationStack {
            ZStack {
                Color.black.ignoresSafeArea()

                ScrollView {
                    VStack(alignment: .leading, spacing: 24) {

                        // Title
                        Text("Loadouts")
                            .font(.custom("ChakraPetch-Bold", size: 34))
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity, alignment: .center)
                            .padding(.top, 24)

                        // Cards
                        ForEach(loadouts) { loadout in
                            loadoutCard(loadout)
                        }

                        Spacer(minLength: 24)
                    }
                    .padding(.horizontal, 16)
                    .padding(.bottom, 16)
                }
            }
            .navigationBarBackButtonHidden(true) // we use our own layout
        }
    }

    // MARK: - Single card
    @ViewBuilder
    private func loadoutCard(_ loadout: SquadLoadout) -> some View {
        ZStack {
            RoundedRectangle(cornerRadius: 24)
                .fill(Color.white.opacity(0.06))

            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    Text(loadout.name)
                        .font(.system(size: 20, weight: .semibold))
                        .foregroundColor(.white)

                    Spacer()

                    Image(systemName: "xmark")
                        .foregroundColor(.white.opacity(0.7))
                        .font(.system(size: 16, weight: .bold))
                }

                Text("\(loadout.playerCount) Players | Type: \(loadout.type.rawValue)")
                    .foregroundColor(.white.opacity(0.7))
                    .font(.system(size: 14))

                HStack {
                    // NavigationLink as the Figma-style "View" button
                    NavigationLink {
                        // For now always show Player 1
                        if let player = loadout.players.first {
                            PlayerLoadoutView(player: player)
                        } else {
                            Text("No players yet")
                                .foregroundColor(.white)
                        }
                    } label: {
                        Text("View")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(.black)
                            .frame(width: 96, height: 44)
                            .background(Color.helldiverYellow)
                            .cornerRadius(22)
                    }
                    .buttonStyle(.plain)

                    Spacer()

                    // Placeholder squares where the small icons will go later
                    HStack(spacing: 8) {
                        ForEach(0..<5, id: \.self) { _ in
                            RoundedRectangle(cornerRadius: 8)
                                .fill(Color.white.opacity(0.10))
                                .frame(width: 32, height: 32)
                        }
                    }
                }
                .padding(.top, 8)
            }
            .padding(16)
        }
        .frame(maxWidth: .infinity)
        .frame(height: 140)
    }
}
