//
//  MyData.swift
//  Helldivers_ios
//
//  Created by csuftitan on 10/23/25.
//

import Foundation
import SwiftUI

struct MyData: App {
        var body: some Scene {
        WindowGroup {RootView()}
    }
}
