//
//  LoadoutModels.swift
//  Helldivers_ios
//
//  Created by Alvaro Contreras on 11/29/25.
//

import Foundation

// MARK: - Basic equipment item coming from backend
struct EquipmentItem: Identifiable, Hashable {
    let id: String        // e.g. "010502"
    let name: String      // e.g. "SG-225 Breaker"
    let imageURL: String  // backend URL for the icon
}

// MARK: - Player loadout (one player on the detail screen)
struct PlayerLoadout: Identifiable, Hashable {
    let id = UUID()
    let playerNumber: Int

    let primary: EquipmentItem
    let secondary: EquipmentItem
    let throwable: EquipmentItem
    let armorPassive: EquipmentItem
    let booster: EquipmentItem
    let stratagems: [EquipmentItem]
}

// MARK: - Squad loadout (one row in the Loadouts list)
enum LoadoutType: String {
    case crowdControl = "Crowd Control"
    case recon = "Recon"
    case explosive = "Explosive"
}

struct SquadLoadout: Identifiable, Hashable {
    let id = UUID()
    let name: String            // "Loadout 1"
    let playerCount: Int        // 1–4
    let type: LoadoutType       // for the subtitle
    let players: [PlayerLoadout]
}

// MARK: - Mock data (UI only for now)
enum MockLoadouts {
    static let sample: [SquadLoadout] = {
        let player1 = PlayerLoadout(
            playerNumber: 1,
            primary: EquipmentItem(
                id: "010502",
                name: "SG-225 Breaker",
                imageURL: "https://helldiversbackend-production.up.railway.app/static/primary/010502.png"
            ),
            secondary: EquipmentItem(
                id: "020201",
                name: "P-92 Warrant",
                imageURL: "https://helldiversbackend-production.up.railway.app/static/secondary/020201.png"
            ),
            throwable: EquipmentItem(
                id: "030103",
                name: "G-6 Frag",
                imageURL: "https://helldiversbackend-production.up.railway.app/static/throwable/030103.png"
            ),
            armorPassive: EquipmentItem(
                id: "050102",
                name: "UAV Recon",
                imageURL: "https://helldiversbackend-production.up.railway.app/static/armor_passive/050102.png"
            ),
            booster: EquipmentItem(
                id: "060101",
                name: "Machine Gun",
                imageURL: "https://helldiversbackend-production.up.railway.app/static/booster/060101.png"
            ),
            stratagems: [
                EquipmentItem(
                    id: "040001",
                    name: "Eagle 110mm",
                    imageURL: "https://helldiversbackend-production.up.railway.app/static/strat/040001.png"
                ),
                EquipmentItem(
                    id: "040002",
                    name: "Orbital 380mm",
                    imageURL: "https://helldiversbackend-production.up.railway.app/static/strat/040002.png"
                ),
                EquipmentItem(
                    id: "040003",
                    name: "Guard Dog",
                    imageURL: "https://helldiversbackend-production.up.railway.app/static/strat/040003.png"
                ),
                EquipmentItem(
                    id: "040004",
                    name: "Extra Strat",
                    imageURL: "https://helldiversbackend-production.up.railway.app/static/strat/040004.png"
                )
            ]
        )

        // duplicate player for now
        return (1...6).map { index in
            SquadLoadout(
                name: "Loadout \(index)",
                playerCount: 4,
                type: .crowdControl,
                players: [player1]   // later this will be real players[0...3]
            )
        }
    }()
}
