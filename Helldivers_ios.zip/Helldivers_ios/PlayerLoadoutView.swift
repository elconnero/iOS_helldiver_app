//
//  PlayerLoadoutView.swift
//  Helldivers_ios
//
//  Created by Alvaro Contreras on 11/29/25.
//

import SwiftUI

struct PlayerLoadoutView: View {
    let player: PlayerLoadout
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            ScrollView {
                VStack(spacing: 24) {

                    // Title
                    Text("Player \(player.playerNumber)")
                        .font(.custom("ChakraPetch-Bold", size: 34))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity, alignment: .center)
                        .padding(.top, 24)

                    // Primary
                    equipmentCard(
                        item: player.primary,
                        large: true
                    )

                    // Secondary + Throwable (2-column)
                    HStack(spacing: 16) {
                        equipmentCard(item: player.secondary)
                        equipmentCard(item: player.throwable)
                    }

                    // Armor passive + booster row
                    HStack(spacing: 16) {
                        equipmentCard(item: player.armorPassive)
                        equipmentCard(item: player.booster)
                    }

                    // Stratagems grid (2x2 like Figma)
                    LazyVGrid(
                        columns: [
                            GridItem(.flexible(), spacing: 16),
                            GridItem(.flexible(), spacing: 16)
                        ],
                        spacing: 16
                    ) {
                        ForEach(player.stratagems) { strat in
                            equipmentCard(item: strat)
                        }
                    }

                    Spacer(minLength: 32)
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 24)
            }
        }
        .navigationBarBackButtonHidden(true)
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
                Button {
                    dismiss()
                } label: {
                    HStack(spacing: 4) {
                        Image(systemName: "chevron.left")
                        Text("Back")
                    }
                    .foregroundColor(.white)
                }
            }
        }
    }

    // MARK: - Card builder

    @ViewBuilder
    private func equipmentCard(item: EquipmentItem, large: Bool = false) -> some View {
        VStack(spacing: 8) {
            ZStack {
                RoundedRectangle(cornerRadius: 18)
                    .fill(Color.white.opacity(0.06))

                // Image from backend URL (UI-only for now)
                AsyncImage(url: URL(string: item.imageURL)) { image in
                    image
                        .resizable()
                        .scaledToFit()
                        .padding(large ? 24 : 16)
                } placeholder: {
                    // Simple grey placeholder box
                    Rectangle()
                        .fill(Color.white.opacity(0.15))
                        .overlay(
                            ProgressView()
                                .tint(.white)
                        )
                        .padding(large ? 24 : 16)
                }
            }
            .frame(height: large ? 220 : 120)

            Text(item.name)
                .font(.system(size: 14, weight: .semibold))
                .foregroundColor(.white)
                .multilineTextAlignment(.center)
        }
    }
}
